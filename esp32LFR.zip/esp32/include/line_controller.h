#pragma once
#include <Arduino.h>

class LineController {
public:
  void begin();
  void reset();

  // returns correction value (float) given error and dt
  float update(float error, float dt);

  void setGains(float kp, float ki, float kd);
  void getGains(float &kp, float &ki, float &kd) const;

private:
  float kp_ = 0, ki_ = 0, kd_ = 0;
  float integral_ = 0;
  float lastErr_ = 0;
};
